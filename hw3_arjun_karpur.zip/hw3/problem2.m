%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                           %
%        Arjun Karpur       %
%   CS 395T (Num opt) Hw 3  %
%         Problem 2         %
%                           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear;
clf;

% Parameters
n = 20;
r = 5;
mu = 0.01;
sparsity = 0.1;
delta_hat = 10;
eta = 1/8;
maxIters = 1000;
thresholdStop = 0.00001;

% Construct data and initialize B,C,x,delta
A = rand(n,n);
G = rand(n,n) < sparsity;
B = rand(n,r);
C = rand(r,n);
x = convertToX(B,C);
delta = delta_hat*.0001;

% Start optimization
iterVals = [];
prevVal = 0;
currVal = evaluate_f(A, G, B, C, mu);
initialVal = currVal;
fprintf('Starting optimization with Cauchy Point Calculation\n', initialVal);
fprintf('Initial energy:\t%f\n', currVal);
for iters=1:maxIters

    % Cauchy point calculations
    p = calcCauchyStep(A, G, B, C, mu, delta);
    rho = calcRho(A, G, mu, n, r, x, p);

    % Update delta as necessary
    if rho < (1/4)
        delta = delta*(1/4);
    else
        if rho > (3/4) && norm(p) == delta
            delta = min(2*delta, delta_hat);
        end
    end

    % Update x as necessary
    if rho >= eta
        x = x + p;
    end

    % Update B,C matrices
    [B, C] = convertToBC(x, n, r);
    
    % Check change in energy
    prevVal = currVal;
    currVal = evaluate_f(A, G, B, C, mu);
    fprintf('Iter #%i:\t%f\n', iters, currVal);
    xAxis(iters) = iters;
    yAxis(iters) = log(currVal);

    % Stop optimization if done
    if abs(currVal - prevVal) < thresholdStop
        fprintf('Finished!\n');
        break;
    end
end
xAxis = [0 xAxis];
yAxis = [log(initialVal) yAxis];

% Plot results
subplot(1,3,1);
plot(xAxis, yAxis);
hold on;
title('Energy over Iterations');
xlabel('# Iterations');
ylabel('Energy (log)');
hold off;

subplot(1,3,2);
show = G*A*G;
show = show - min(show(:));
show = show ./ max(show(:));
image(show, 'CDataMapping', 'scaled');
title('Normalized G*A*G');
colorbar;

subplot(1,3,3);
show = B*C;
show = show - min(show(:));
show = show ./ max(show(:));
image(show, 'CDataMapping', 'scaled');
title('Normalized B*C');
colorbar;

%%%%%%%%%%%%%%%%%
%    HELPERS    %
%%%%%%%%%%%%%%%%%

% Evaluate objective function
function val = evaluate_f(A, G, B, C, mu)
    val = 0;

    % First term
    n = size(A,1);
    for r=1:n
        for c=1:n
            if G(r,c) == 0
                continue;
            end
            I = eye(n,n);
            b_row = I(:,r)' * B;
            c_col = C * I(:,c);
            term = A(r,c) - (b_row * c_col);
            val = val + term^2;
        end
    end

    % Second term (frob norms)
    one = norm(B,'fro')^2;
    two = norm(C,'fro')^2;
    val = val + (mu/2)*(one + two);
end

function val = evaluate_m(A, G, mu, n, r, x, p)
    [B, C] = convertToBC(x, n, r);
    f = evaluate_f(A, G, B, C, mu);
    g = calcGrad(A, G, B, C, mu);
    H = calcHessian(A, G, B, C, mu);
    val = f + g'*p + (1/2)*(p'*H*p);
end

% Convert from B,C to x vector
function x = convertToX(B, C)
    [n,r] = size(B);
    I = eye(n);
    x = zeros(2*n*r, 1);
    for i=1:n
        e_i = I(:,i);
        B_i = (e_i' * B)';
        C_i = C * e_i;

        base = (i-1)*r + 1;
        x(base:base+r-1, 1) = B_i(:);
        x((r*n+base):(r*n+base+r-1),1) = C_i(:);
    end
end

% Convert from x representation to B,C
function [B, C] = convertToBC(x, n, r)
    B = zeros(n,r);
    C = zeros(r,n);
    for i=1:n
        base = (i-1)*r + 1;
        B_i = x(base:base+r-1,1)';
        C_i = x((r*n+base):(r*n+base+r-1),1);
        B(i,:) = B_i(:);
        C(:,i) = C_i(:);
    end
end

function p = calcCauchyStep(A, G, B, C, mu, delta)
    g = calcGrad(A, G, B, C, mu);
    H = calcHessian(A, G, B, C, mu);

    p_norm = (-delta)*(g/norm(g));
    tau = 0;
    if g'*H*g <= 0
        tau = 1;
    else
        term = (norm(g)^3)/(delta*g'*H*g);
        tau = min(1, term);
    end
    p = p_norm * tau;
end

function rho = calcRho(A, G, mu, n, r, x, p)
    [B, C] = convertToBC(x, n, r);
    [B_step, C_step] = convertToBC(x+p, n, r);
    num = evaluate_f(A, G, B, C, mu) - ...
        evaluate_f(A, G, B_step, C_step, mu);
    denom = evaluate_m(A, G, mu, n, r, x, zeros(size(p))) - ...
        evaluate_m(A, G, mu, n, r, x, p);
    rho = num/denom;
end

function g = calcGrad(A, G, B, C, mu)
    [n,r] = size(B);
    g = zeros(2*n*r,1);
    for i=1:n
        d_Bi = calc_d_Bi(A, G, B, C, mu, i)';
        d_Cj = calc_d_Cj(A, G, B, C, mu, i);
        base = (i-1)*r + 1;
        g(base:base+r-1, 1) = d_Bi(:);
        g((r*n+base):(r*n+base+r-1),1) = d_Cj(:);
    end
end

function d_Bi = calc_d_Bi(A, G, B, C, mu, i)
    [n, r] = size(B);
    I = eye(n);

    term_one = zeros(1, r);
    for j=1:n
        if G(i,j) == 0
            continue
        end
        e_j = I(:,j);
        term_one = term_one + A(i,j) * (C * e_j)';
    end
    term_one = term_one * -2;

    term_two = zeros(1,r);
    for j=1:n
        if G(i,j) == 0
            continue
        end
        e_i_T = I(:,i)';
        e_j = I(:,j);
        term_two = term_two + ((e_i_T * B)*(C * e_j)*(C * e_j)');
    end
    term_two = term_two * 2;

    e_i_T = I(:,i)';
    term_three = mu*e_i_T*B;

    d_Bi = term_one + term_two + term_three;
end

function d_Cj = calc_d_Cj(A, G, B, C, mu, j)
    [n, r] = size(B);
    I = eye(n);

    term_one = zeros(r,1);
    for i=1:n
        if G(i,j) == 0
            continue
        end
        e_i_T = I(:,i)';
        term_one = term_one + (A(i,j) * (e_i_T * B)');
    end
    term_one = term_one * -2;

    term_two = zeros(r,1);
    for i=1:n
        if G(i,j) == 0
            continue
        end
        e_i_T = I(:,i)';
        e_j = I(:,j);
        term_two = term_two + ((e_i_T * B)*(C*e_j)*(e_i_T * B)');
    end
    term_two = term_two * 2;

    e_j = I(:,j);
    term_three = mu* C * e_j;

    d_Cj = term_one + term_two + term_three;
end

function H = calcHessian(A, G, B, C, mu)
    [n,r] = size(B);
    offset = n*r;
    H = zeros(2*n*r);

    % Compute dBi*
    for i=1:n
        %d2Bi
        d2Bi = calc_d2Bi(G, C, mu, i);
        topLeft = [(i-1)*r+1, (i-1)*r+1];
        H(topLeft(1):topLeft(1)+r-1, topLeft(2):topLeft(2)+r-1) = d2Bi;
        
        %dBiCj
        for j=1:n
            dBiCj = calc_dBiCj(A, G, B, C, i, j);
            topLeft = [(i-1)*r+1, offset+(j-1)*r+1];
            H(topLeft(1):topLeft(1)+r-1, topLeft(2):topLeft(2)+r-1) = dBiCj;
        end
    end

    % Compute dCi*
    for i=1:n

        %dCiBj
        for j=1:n
            dCiBj = calc_dBiCj(A, G, B, C, j, i);
            topLeft = [offset+(i-1)*r+1, (j-1)*r+1];
            H(topLeft(1):topLeft(1)+r-1, topLeft(2):topLeft(2)+r-1) = dCiBj;
        end

        %dCiCj
        d2Ci = calc_d2Cj(G, B, mu, i);
        topLeft = [offset+(i-1)*r+1, offset+(i-1)*r+1];
        H(topLeft(1):topLeft(1)+r-1, topLeft(2):topLeft(2)+r-1) = d2Ci;
    end
end

function d2Bi = calc_d2Bi(G, C, mu, i)
    [r,n] = size(C);
    d2Bi = zeros(r);
    I = eye(n);

    for j=1:n
        if G(i,j) == 0
            continue
        end
        e_j = I(:,j);
        d2Bi = d2Bi + (C*e_j)*(C*e_j)';
    end
    d2Bi = d2Bi*2;
    d2Bi = d2Bi + mu*eye(r);
end

function d2Cj = calc_d2Cj(G, B, mu, j)
    %TODO
    [n,r] = size(B);
    d2Cj = zeros(r);
    I = eye(n);
    
    for i=1:n
        if G(i,j) == 0
            continue
        end
        e_i_T = I(:,i)';
        d2Cj = d2Cj + (e_i_T*B)'*(e_i_T*B);
    end
    d2Cj = d2Cj * 2;
    d2Cj = d2Cj + mu*eye(r);
end

function dBiCj = calc_dBiCj(A, G, B, C, i, j)
    [n, r] = size(B);
    dBiCj = zeros(r);
    I = eye(n);
    e_i_T = I(:,i)';
    e_j = I(:,j);

    dBiCj = dBiCj + -2*G(i,j)*A(i,j)*eye(r);
    dBiCj = dBiCj + 2*G(i,j)*((e_i_T*B)'*(C*e_j)' + (e_i_T*B)*(C*e_j)*eye(r));
end
