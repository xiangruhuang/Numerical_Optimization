%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                           %
%        Arjun Karpur       %
%   CS 395T (Num opt) Hw 3  %
%         Problem 1         %
%                           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear;
clf;

% Parameters
n = 20;
r = 5;
mu = 0.01;
sparsity = 0.1;
maxIters = 1000;
thresholdStop = 0.00001;

% Construct data and initialize B,C
A = rand(n,n);
G = rand(n,n) < sparsity;
B = rand(n,r);
C = rand(r,n);

% Start optimization
iterVals = []
prevVal = 0;
currVal = evaluate(A, G, B, C, mu);
initialVal = currVal;
fprintf('Starting optimization with Alternating Minimization\n', initialVal);
fprintf('Initial energy:\t%f\n', currVal);
for iters=1:maxIters
    % Alternating min steps
    B = stepB(A, G, B, C, mu);
    C = stepC(A, G, B, C, mu);

    % Check change in energy
    prevVal = currVal;
    currVal = evaluate(A, G, B, C, mu);
    fprintf('Iter #%i:\t%f\n', iters, currVal);
    xAxis(iters) = iters;
    yAxis(iters) = log(currVal);

    % Stop optimization if done
    if abs(currVal - prevVal) < thresholdStop
        fprintf('Finished!\n');
        break;
    end
end
xAxis = [0 xAxis];
yAxis = [log(initialVal) yAxis];

% Plot results
subplot(1,3,1);
plot(xAxis, yAxis);
hold on;
title('Energy over Iterations');
xlabel('# Iterations');
ylabel('Energy (log)');
hold off;

subplot(1,3,2);
show = G*A*G;
show = show - min(show(:));
show = show ./ max(show(:));
image(show, 'CDataMapping', 'scaled');
title('Normalized G*A*G');
colorbar;

subplot(1,3,3);
show = B*C;
show = show - min(show(:));
show = show ./ max(show(:));
image(show, 'CDataMapping', 'scaled');
title('Normalized B*C');
colorbar;

%%%%%%%%%%%%%%%%%
%    HELPERS    %
%%%%%%%%%%%%%%%%%

% Evaluate objective function
function val = evaluate(A, G, B, C, mu)
    val = 0;

    % First term
    n = size(A,1);
    for r=1:n
        for c=1:n
            if G(r,c) == 0
                continue;
            end
            I = eye(n,n);
            b_row = I(:,r)' * B;
            c_col = C * I(:,c);
            term = A(r,c) - (b_row * c_col);
            val = val + term^2;
        end
    end

    % Second term (frob norms)
    one = norm(B,'fro')^2;
    two = norm(C,'fro')^2;
    val = val + (mu/2)*(one + two);
end

function B = stepB(A, G, B, C, mu)
    n = size(A,1);
    r = size(B,2);

    % Solve for each row of B
    for i=1:n
        % Set M
        M_one = zeros(r,r);
        I = eye(n);
        for j=1:n
            if G(i,j) == 0
                continue
            end
            e_j = I(:,j);
            M_one = M_one + ((C * e_j) * (C * e_j)');
        end
        M_two = mu * eye(r);
        M = (2*M_one + M_two)';
        
        % Set b
        b = zeros(r,1);
        for j=1:n
            if G(i,j) == 0
                continue
            end
            e_j = I(:,j);
            b = b + (A(i,j) * (C * e_j));
        end
        b = 2*b;
        
        % Solve for x = M^-1 b = = (e_i^T B)'
        x = M\b;
        B(i,:) = x';
    end
end

function C = stepC(A, G, B, C, mu)
    n = size(A,1);
    r = size(B,2);

    % Solve for each row of B
    for j=1:n

        % Set M
        I = eye(n);
        M_one = zeros(r,r);
        for i=1:n
            if G(i,j) == 0
                continue
            end
            e_i = I(:,i);
            M_one = M_one + ((e_i' * B)' * (e_i' * B));
        end
        M_two = mu * eye(r);
        M = 2*M_one + M_two;

        % Set b
        b = zeros(r,1);
        for i=1:n
            if G(i,j) == 0
                continue
            end
            e_i = I(:,i);
            b = b + (A(i,j) * (e_i'*B)');
        end
        b = 2*b;

        % Solve for x = M^-1 b = (C e_j)
        x = M \ b;
        C(:,j) = x;
    end
end
