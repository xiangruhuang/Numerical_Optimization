function [Data] = load_data(foldername)
%
map_folder = [foldername, '/initial_maps/'];
shape_folder = [foldername, '/shapes/'];
temp = dir(shape_folder);
numShapes = (length(temp)-2)/2;
for shapeId = 1 : numShapes
    str = sprintf('%d.obj', shapeId);
    Data.shapes{shapeId}.mesh = loadfobj([shape_folder, str]);
    str = sprintf('%d.txt', shapeId);
    Data.shapes{shapeId}.featureIds = load_feature([shape_folder, str]);
    fprintf('Finished loading shape_%d\n', shapeId);
end

% Load maps
for sId = 1 : numShapes
    for tId = 1 : numShapes
        if tId == sId
            continue;
        end
        str = sprintf('%d_%d.txt', sId, tId);
        map.sId = sId;
        map.tId = tId;
        map.corres = load_corres([map_folder, str]);
        Data.initial_maps{sId, tId} = map;
        fprintf('Finished loading map_%d_%d\n', sId, tId);
    end
end

function [corres] = load_corres(filename)
%
corres = load(filename);
corres = corres' + 1;
 
function [featureIds] = load_feature(filename)
featureIds = load(filename);
featureIds = featureIds(2:length(featureIds))+1;