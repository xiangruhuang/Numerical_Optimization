function [Data_out] = dms_generation(Data, numSamples)
% Generate samples on the input shapes
numShapes = length(Data.shapes);
Data_out = Data;
parfor shapeId = 1 : numShapes
    SAMPLE{shapeId} = fps_sampling(...
        Data.shapes{shapeId}, numSamples);
    fprintf('Finished sampling shape_%d\n', shapeId);
end
Data_out.SAMPLE = SAMPLE;
for sId = 1 : numShapes
    for tId = 1 : numShapes
        if tId == sId
            continue;
        end
        corres = Data.initial_maps{sId, tId}.corres;
        Data_out.initial_maps{sId, tId}.sample_corres =...
            corres_2_sampleCorres(corres, Data_out.SAMPLE{sId}, Data_out.SAMPLE{tId});
        fprintf('Finished converting map_%d_%d\n', sId, tId);
    end
end
%
function [sample_corres] = corres_2_sampleCorres(corres, SAMPLE_s, SAMPLE_t)
%
tvIds = corres(2, SAMPLE_s.sampleIds);
tsIds = SAMPLE_t.closestSampleIds(tvIds);
sample_corres = [1:length(tsIds); tsIds];
