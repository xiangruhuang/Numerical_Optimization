function [ pk, g, b ] = cauchy( A, B, C, G, mu, n, r, delta_k )
%% first order

B_hat = reshape(B,[],1);
C_hat = reshape(C,[],1);

M_B = zeros(r*n,r*n);
N_B = zeros(1,r*n);
for i = 1:n
    for j = 1:n
        if G(i,j) == 0
            continue
        end
        rows = 1:r;
        cols = (j-1) * r + (1:r); % the jth column of matrix C
        Mijc = sparse(rows, cols, 1, r, r*n);

        rows = 1:r;
        cols = n * (0:r-1) + i; % the ith row of matrix B
        Mijb = sparse(rows, cols, 1, r, r*n);

        M_B = M_B + G(i,j)*Mijb'*Mijc*C_hat*C_hat'*Mijc'*Mijb;
        N_B = N_B + A(i,j)*G(i,j)*C_hat'*Mijc'*Mijb;
    end
end
M_B = M_B + mu/2*eye(n*r);
gb = M_B*B_hat - N_B';

M_C = zeros(r*n,r*n);
N_C = zeros(1,r*n);
for i = 1:n
    for j = 1:n
        if G(i,j) == 0
            continue
        end
        rows = 1:r;
        cols = (j-1) * r + (1:r); % the jth column of matrix C
        Mijc = sparse(rows, cols, 1, r, r*n);

        rows = 1:r;
        cols = n * (0:r-1) + i; % the ith row of matrix B
        Mijb = sparse(rows, cols, 1, r, r*n);

        M_C = M_C + G(i,j)*Mijc'*Mijb*B_hat*B_hat'*Mijb'*Mijc;
        N_C = N_C + A(i,j)*G(i,j)*B_hat'*Mijb'*Mijc;
    end
end
M_C = M_C + mu/2*eye(n*r);
gc = M_C*C_hat - N_C';

g = [gb;gc];

%% second order
M_CB = zeros(r*n,r*n);
N_CB = zeros(1,r*n);
for i = 1:n
    for j = 1:n
        if G(i,j) == 0
            continue
        end
        rows = 1:r;
        cols = (j-1) * r + (1:r); % the jth column of matrix C
        Mijc = sparse(rows, cols, 1, r, r*n);

        rows = 1:r;
        cols = n * (0:r-1) + i; % the ith row of matrix B
        Mijb = sparse(rows, cols, 1, r, r*n);

        M_CB = M_CB + G(i,j)*Mijb'*Mijc*Mijc'*Mijb;
        N_CB = N_CB + A(i,j)*G(i,j)*Mijb'*Mijc;
    end
end
M_CB = M_CB * B_hat;
M_BC = zeros(r*n,r*n);
N_BC = zeros(1,r*n);
for i = 1:n
    for j = 1:n
        if G(i,j) == 0
            continue
        end
        rows = 1:r;
        cols = (j-1) * r + (1:r); % the jth column of matrix C
        Mijc = sparse(rows, cols, 1, r, r*n);

        rows = 1:r;
        cols = n * (0:r-1) + i; % the ith row of matrix B
        Mijb = sparse(rows, cols, 1, r, r*n);

        M_BC = M_BC + G(i,j)*Mijc'*Mijb*Mijb'*Mijc;
        N_BC = N_BC + A(i,j)*G(i,j)*Mijc'*Mijb;
    end
end
M_BC = M_BC * C_hat;
b = 2*[M_B, M_BC*B_hat'-N_BC;M_CB*C_hat'-N_BC, M_C];


pk = -delta_k*(g./norm(g)); 
condition = g'*b*g;
% determine tk
if condition <= 0
    tk = 1;
else
    tk = min(1, norm(g)^3/(delta_k*condition));
end
pk = tk*pk;
end

