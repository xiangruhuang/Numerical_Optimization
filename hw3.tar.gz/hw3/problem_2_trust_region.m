function [obj] = problem_2_trust_region(A, B, C, G, mu, n, r)

delta_k = 0.5; 
delta_hat = 1;
eta = 0.2;
iters = 20;
obj = zeros(n, 1);

for iter=1:iters
    o = objective( A, B, C, G, mu);
    obj(iter) = o;
    fprintf('iteration %d, objective: %f.\n', iter, o);
    [pk, gk, bk] = cauchy(A, B, C, G, mu, n, r, delta_k); 
    rhok = ( o - objective( A, B + reshape(pk(1:n*r), [n r]), ...
           C + reshape(pk(n*r+1:2*n*r), [r n]), G, mu )) / ...
           ( o - subProblem(o, pk, gk, bk));
    if rhok < 1/4
        delta_k = 1/4*delta_k;
    else
        if rhok > 3/4 && norm(pk) == delta_k
            delta_k = min(2*delta_k, delta_hat);
        end
    end
    if rhok >= eta
        B = B + reshape(pk(1:n*r), [n r]);
        C = C + reshape(pk(n*r+1:2*n*r), [r n]);
    end
end

function [ mk ] = subProblem( fk, pk, gk, bk )
mk = fk + gk'* pk + 0.5*pk'*bk*pk;