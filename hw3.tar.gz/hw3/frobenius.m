function [n] = frobenius(A)
a = power(A,2);
n = sum(reshape(a,[],1));