mu = 0.01;
n = 10;
r = 5;
A = randn(n,n);
G = (rand(n,n) > 0.2);
B = randn(n,r);
C = randn(r,n);

obj_alt = problem_1_alternating(A, B, C, G, mu, n, r);
obj_tru = problem_2_trust_region(A, B, C, G, mu, n, r);

plot(obj_alt);
hold on;
plot(obj_tru);

legend('alternating', 'trust region')

