function [obj] = problem_1_alternating(A, B, C, G, mu, n, r)
% find low rank approximation to data matrix A
% A = BC

% mu = 0.01;
% n = 10;
% r = 5;
% A = randn(n,n);
% G = (rand(n,n) > 0.2);
% B = randn(n,r);
% C = randn(r,n);

B_hat = reshape(B,[],1);
C_hat = reshape(C,[],1);
iters = 10;
obj = zeros(iters,1);

for iter = 1:iters
    
    % 
    o = objective(A, B, C, G, mu);
    obj(iter) = o;
    fprintf('iteration %d, objective: %f.\n', iter, o);
 
    % fix B, optimize C
    M = zeros(r*n,r*n);
    N = zeros(1,r*n);
    for i = 1:n
        for j = 1:n
            if G(i,j) == 0
                continue
            end
            rows = 1:r;
            cols = (j-1) * r + (1:r); % the jth column of matrix C
            Mijc = sparse(rows, cols, 1, r, r*n);
            
            rows = 1:r;
            cols = n * (0:r-1) + i; % the ith row of matrix B
            Mijb = sparse(rows, cols, 1, r, r*n);
            
            M = M + G(i,j)*Mijc'*Mijb*B_hat*B_hat'*Mijb'*Mijc;
            N = N + A(i,j)*G(i,j)*B_hat'*Mijb'*Mijc;
        end
    end
    M = M + mu/2*eye(n*r);
    C_hat = M\N';
    
    % fix C, optimize B
    
    M = zeros(r*n,r*n);
    N = zeros(1,r*n);
    for i = 1:n
        for j = 1:n
            if G(i,j) == 0
                continue
            end
            rows = 1:r;
            cols = (j-1) * r + (1:r); % the jth column of matrix C
            Mijc = sparse(rows, cols, 1, r, r*n);
            
            rows = 1:r;
            cols = n * (0:r-1) + i; % the ith row of matrix B
            Mijb = sparse(rows, cols, 1, r, r*n);
            
            M = M + G(i,j)*Mijb'*Mijc*C_hat*C_hat'*Mijc'*Mijb;
            N = N + A(i,j)*G(i,j)*C_hat'*Mijc'*Mijb;
        end
    end
    M = M + mu/2*eye(n*r);
    B_hat = M\N';
    
    %
    C = reshape(C_hat, r, []);
    B = reshape(B_hat, [], r);
    
    
end

