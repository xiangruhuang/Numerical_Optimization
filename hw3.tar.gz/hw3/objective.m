function [o] = objective(A,B,C,G,mu)
a = frobenius(G.*(A - B*C));
o = a + mu/2*(frobenius(B) + frobenius(C));

