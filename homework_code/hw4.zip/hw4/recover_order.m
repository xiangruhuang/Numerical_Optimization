function [newdata] = recover_order(data,org_order)
% This function recovers the order of the array
[x,~] = size(data);
newdata = zeros(x,1);

for i=1:1:x
    newdata(org_order(i)) = data(i);
end

end

