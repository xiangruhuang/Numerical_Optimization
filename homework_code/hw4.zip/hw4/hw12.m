clear;
load('hw4_data.mat');

%% Hyper-parameters to be tuned
t = 0.01;%step size
lambda = 50;
numE = 100;
obj_vals = zeros(numE+1,1);
[N,~] = size(A);
[~,M] = size(A{1,1});
x = cell(N, 1);
for i=1:1:10
    x{i,1} = normrnd(0,0.02,[M 1]);
end

%% Proximal Gradient Descent
obj_vals(1) = objective_val(A,b,x,lambda);
for numI=1:1:numE
    %% Gradient descent on the g(x) term
    for i=1:1:N
        x{i,1} = x{i,1} - t*2*A{i,1}'*(A{i,1}*x{i,1} - b{i,1});
    end
    %% Proximal Gradient Descent, we operate for each dimension independently
    for i=1:1:M
       prox_x = zeros(N, 1);
       prox_y = zeros(N, 1);
       for j=1:1:N
           xi = x{j,1};
           prox_x(j) = xi(i); 
       end
       % sort the array here
       [newx, order] = sort(prox_x);
       for j=1:1:N
           prox_y(j) = newx(j) + t*lambda*(N - 2*j +1); 
       end
       % isotonic regression
       a = zeros(N,1);
       a(1) = prox_y(1);
       w = ones(N,1);
       j = 1;
       s = zeros(N,1);
       s(1) = 1;
       for numi=2:1:N
           j = j + 1;
           a(j) = prox_y(numi);
           w(j) = 1;
           while j > 1 && a(j) < a(j-1)
               a(j-1) = (w(j)*a(j) + w(j-1)*a(j-1))/(w(j) + w(j-1));
               w(j-1) = w(j) + w(j-1);
               j = j - 1;
           end
           s(j) = numi;
       end
       for k=1:1:j
           if k == 1
               sinit = 0;
           else
               sinit = s(k-1);
           end
           for l=sinit+1:1:s(k)
               prox_x(l) = a(k);
           end
       end
       newx_ordered = recover_order(prox_x, order);
       for j=1:1:N
           xi = x{j,1};
           xi(i) = newx_ordered(j);
           x{j,1} = xi;
       end
    end
    obj_vals(numI+1) = objective_val(A,b,x,lambda);
end
plot(obj_vals);
ylabel('objective value');
xlabel('# Iterations');