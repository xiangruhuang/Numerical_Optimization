function [val] = objective_val(A,b,x, lambda)
%This function calculates the objective value of the loss function.
[N,~] = size(A);
val = 0;
for i=1:1:N
   Ai = A{i,1};
   bi = b{i,1};
   xi = x{i,1};
   val = val + norm(Ai*xi-bi)*norm(Ai*xi-bi);
end
for i=1:1:N-1
    for j=i+1:1:N
        val = val + lambda*sum(abs(x{i,1} - x{j,1}));
    end
end
end

