The main code is in hw12.m. The hyper-parameters are defined in the beginning.
x is initialized with gaussian noise with variance 0.02. The objective_val.m
calculates the objective value of given A,b,x and lambda, and the 
recover_order.m is a utility function used for recoverring the order of x
in each dimension before the sorting.

Running hw12.m gives one graph, with objective value vs number of iterations.
We can see that the objective value decreases and coverges to a stable point. 