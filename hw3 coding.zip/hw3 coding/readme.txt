This file contains 7 scripts and 1 pdf, the pdf is explaining the methods of solving
Q1. In order to see the results, run Q1.m directly. 

f.m : evaluate the objective function, the input should be unfolded vector
gradient.m : calculate the gradient with respect to unfolded vector
Hessian.m : calculate the Hessian with respect to unfolded vector
trust_region.m : scheme for trust-region method
alter_direction.m: scheme for coordinate descent method
recover_mat.m: recover the matrix B and C from vector
Q1.m: executive file