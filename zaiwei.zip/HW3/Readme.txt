This folder contains the code for problem 1 and 2, using Trust Region 
and Alternating minimization method.

The technical details have been mentioned in the pdf file.

Problem1_2_Alternating.m is the main script utilizing alternating 
minimization method, and Problem1_2_TrustRegion.m is the main script 
utilizing Trust Region method. All other functions are utility functions.
Each of them is commented.

The two scripts will output a graph of objective values versus number of 
iterations.
